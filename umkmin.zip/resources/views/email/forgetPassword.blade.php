<h1>Forget Password Email</h1>
   
You can reset password from bellow link:
<a class="btn btn-primary" href="{{ route('reset.password.get', $token) }}">Reset Password</a>