       {{-- <div class=" mt-2 d-flex justify-content-evenly">
                                <div class="col-4 form-floating ">
                                    <input type="text" class="form-control rounded-top @error('name') is-invalid @enderror"
                                        name="name" id="name" placeholder="Nama lengkap" required value="{{ old('nama') }}">
                                    <label for="name">Name</label>
                                    @error('name')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                
                                <div class="col-4 form-floating">
                                    <input type="text" class="form-control rounded-top @error('telp') is-invalid @enderror"
                                    name="telp" id="telp" placeholder="Telp" required value="{{ old('telp') }}">
                                    <label for="telp">Telp</label>
                                    @error('telp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                    </div>

                                    
                                <div class="col-4 form-floating " >
                                    <textarea class="form-control rounded-top @error('password_confirmation') is-invalid @enderror" placeholder="Leave a comment here" id="desc" name="desc" style="height: 150px" required>{{ old('password_confirmation') }}</textarea>
                                <label for="desc">Deskripsi Umkm</label>
                                @error('desc')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            </div>

                            <div class=" mt-2 d-flex justify-content-evenly">
                                <div class="col-5 form-floating">
                                    <input type="text" class="form-control rounded-top @error('username') is-invalid @enderror"
                                        name="username" id="username" placeholder="Username" required
                                        value="{{ old('username') }}">
                                    <label for="username">Username</label>
                                    @error('username')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-5 form-floating">
                                    <input type="text" class="form-control rounded-top @error('address') is-invalid @enderror"
                                        name="address" id="address" placeholder="Alamat" required
                                        value="{{ old('address') }}">
                                    <label for="address">Alamat</label>
                                    @error('address')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>

                            <div class=" mt-2 d-flex justify-content-evenly">
                                <div class="col-5 form-floating " >
                                    <input type="email" class="form-control rounded-top @error('email') is-invalid @enderror"
                                        name="email" id="email" placeholder="Email" required value="{{ old('email') }}">
                                    <label for="email">Email</label>
                                    @error('email')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-5 form-floating " >
                                    <input type="website" class="form-control rounded-top @error('website') is-invalid @enderror"
                                        name="website" id="website" placeholder="Website" value="{{ old('website') }}">
                                    <label for="website">Website</label>
                                    @error('website')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>

                            <div class=" mt-2 d-flex justify-content-evenly">
                                <div class="col-5 form-floating" >
                                    <input type="password" class="form-control rounded-top @error('password') is-invalid @enderror"
                                        name="password" id="password" placeholder="Kata sandi" required
                                        value="{{ old('password') }}">
                                    <label for="password">Password</label>
                                    @error('password')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                                <div class="col-5 form-floating" >
                                    <input type="business_sector" class="form-control rounded-top @error('business_sector') is-invalid @enderror"
                                        name="business_sector" id="business_sector" placeholder="Sektor Bisnis" value="{{ old('business_sector') }}">
                                    <label for="business_sector">Sektor Bisnis</label>
                                    @error('business_sector')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                            </div>

                            <div class=" mt-2 d-flex justify-content-evenly">
                                
                                <div class="col-5 form-floating" >
                                    <input type="password"
                                        class="form-control rounded-top @error('password_confirmation') is-invalid @enderror"
                                        name="password_confirmation" id="password_confirmation"
                                        placeholder="Konfirmasi kata sandi" required value="{{ old('password_confirmation') }}">
                                    <label for="name">Konfirmasi password</label>
                                    @error('name')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
    
                            </div>
                            --}}

                           
                           