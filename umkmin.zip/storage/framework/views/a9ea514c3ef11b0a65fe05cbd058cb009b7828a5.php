

<?php $__env->startSection('container'); ?>

<div class="container">
    <div class="row text-center">
        <div class="bg-image text-white" style="background-image: url('/assets/bg1.png'); height:70vh">
            <div class="mx-auto" >
            <div class="mt-5">
                <h1>Kembangkan Bisnis Anda Bersama UMKM.IN</h1>
                <h6 class="mt-5" >Temukan berbagai layanan digital di UMKM.IN, mulai dari pembaruan profil perusahaan,
                    promosi produk, hingga layanan digital menarik lainnya. Jadi, apa yang anda tunggu? Mari bergabung
                    dengan kami</h5>
            </div>
            <form class="row g-1 justify-content-center mt-5">
                <div class="col-3">
                    <label for="cariPerusahaan" class="visually-hidden"></label>
                    <input type="text" class="form-control" id="cariPerusahaan"
                        placeholder="Cari perusahaan atau produk">
                </div>
                <div class="col-2">
                    <label for="cariLokasi" class="visually-hidden"></label>
                    <input type="text" class="form-control" id="cariLokasi" placeholder="Lokasi">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-success mb-3">Cari</button>
                </div>
            </form>
        </div>
        </div>
        

    </div>

    <div class="row align-items-center bg-nyala ">
        <div class="col">
            <div class="row mt-4">
                <div class="col-2">
                    <img src="<?php echo e(asset('/assets/claim.png')); ?>" alt="">
                </div>
                <div class="col-9">
                    <h5>Klaim Informasi Bisnis Anda</h5>
                    <p>Kami akan mengirimkan informasi bisnis anda kepada anda melalui email</p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="row mt-4">
                <div class="col-2">
                    <img src="<?php echo e(asset('/assets/megaphone.png')); ?>" alt="">
                </div>
                <div class="col-9">
                    <h5>Promosikan Bisnis Anda</h5>
                    <p>Kami akan mengirimkan promosi bisnis anda kepada anda melalui email</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-5 mb-5">
        <div class="col">
            <h3 class="text-center mb-5">Daftar Perusahaan</h3>
            <div class="row justify-content-center ">
                <div class="row">

                    <div class="col-sm-3 mb-4">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-profile" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">UMKM REPUBLIKA</h5></a>
                                <p class="card-text fw-light hurufkecil">Jl. Raya Kediri - Nganjuk, Santren Lor</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-profile" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">UMKM GO ONLINE</h5></a>
                                <p class="card-text fw-light hurufkecil">Jl. Medan Merdeka Barat no. 9</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-profile" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">PRO UMKM</h5></a>
                                <p class="card-text fw-light hurufkecil">Jl. H. Rais A. Rachman No.229</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-profile" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">KEMENKOP UKM</h5></a>
                                <p class="card-text fw-light hurufkecil">Jl. H. R. Rasuna Said No.Kav. 3-4</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-profile" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">PADI UMKM</h5></a>
                                <p class="card-text fw-light hurufkecil">Jl. Kebon Sirih Kav 10-12, RT 11 / RW 2</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-profile" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">SAHABAT UMKM</h5></a>
                                <p class="card-text fw-light hurufkecil">Jl. Kebon Kacang Raya No.25, RT.4/RW.8</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-profile" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">TEMAN UMKM</h5></a>
                                <p class="card-text fw-light hurufkecil">Jln Baturan Raya 34, RT.02/RW.19</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-profile" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">UMKM LAYAK</h5></a>
                                <p class="card-text fw-light hurufkecil">Jl. Angkasa B-9 Kavling 6, Kota Baru Bandar</p>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="/companies" class="mt-3 text-end" style="text-decoration: none">Lihat Lebih Banyak</a>
            </div>
        </div>
    </div>

    <div class="row mt-5 mb-5 bg-nyala">
        <div class="col">
            <h3 class="text-center mb-5 mt-5">Daftar Produk</h3>
            <div class="row justify-content-center ">
                <div class="row">

                    <div class="col-sm-3 mb-4">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?product" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-catalog-1" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">Kerupuk</h5></a>
                                <p class="card-text fw-light hurufkecil">Kerupuk Kalsium Tulang Lele</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?product" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-catalog-1" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">Mie</h5></a>
                                <p class="card-text fw-light hurufkecil">Mie Kelor Ammatri</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?product" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-catalog-1" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">Abon</h5></a>
                                <p class="card-text fw-light hurufkecil">Abon Ikan Tuna</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?product" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-catalog-1" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">Kopi</h5></a>
                                <p class="card-text fw-light hurufkecil">Kopi Celup Gahwi</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?product" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-catalog-1" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">Sepatu</h5></a>
                                <p class="card-text fw-light hurufkecil">Sepatu Boot Kulit</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?product" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-catalog-1" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">Kalung</h5></a>
                                <p class="card-text fw-light hurufkecil">Kalung Kerang Batik</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?product" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-catalog-1" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">Kursi</h5></a>
                                <p class="card-text fw-light hurufkecil">Kursi Rotan Twinpan</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?product" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/company-catalog-1" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar">Batik</h5></a>
                                <p class="card-text fw-light hurufkecil">Atasan Batik Wanita</p>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="/products" class="mt-3 mb-3 text-end" style="text-decoration: none">Lihat Lebih Banyak</a>
            </div>
        </div>
    </div>

    <div class="row mt-5 mb-5">
        <div class="col">
            <h3 class="text-center mb-5">Berita Terbaru</h3>
            <div class="row justify-content-center ">
                <div class="row">

                    <div class="col-sm-4">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?news" class="card-img-top" alt="...">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <a href="" style="text-decoration: none">April 15, 2022</a>
                                    <a href="" style="text-decoration: none">UMKM.IN News</a>
                                </div>
                                <p class="card-text fw-bold hurufbesar">Mantap! Tembus Rp 156M, Komoditas Ikan Bali
                                    diminati di Amerika
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?news" class="card-img-top" alt="...">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <a href="" style="text-decoration: none">April 15, 2022</a>
                                    <a href="" style="text-decoration: none">UMKM.IN News</a>
                                </div>
                                <p class="card-text fw-bold hurufbesar">Ini 'Pahlawan' yang Bikin Neraca Dagang RI
                                    Surplus 23 Kali Beruntun
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?news" class="card-img-top" alt="...">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <a href="" style="text-decoration: none">April 15, 2022</a>
                                    <a href="" style="text-decoration: none">UMKM.IN News</a>
                                </div>
                                <p class="card-text fw-bold hurufbesar">Jajanan Lokal RI Bisa Tembus Pasar Ekspor,
                                    Caranya?
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="" class="mt-3 text-end" style="text-decoration: none">Lihat Lebih Banyak</a>
            </div>
        </div>
    </div>


    


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-uiux\resources\views/home.blade.php ENDPATH**/ ?>