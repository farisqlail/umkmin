

<?php $__env->startSection('body'); ?>

<?php if(session()->has('success')): ?>

<div class="alert alert-succes alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>

<?php elseif(session()->has('danger')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?php echo e(session('danger')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>
 

<div class="row mt-5 ms-5 me-5">
    <div class="col">
        <ul class="nav nav-tabs">
            <li class="nav-item">
              <a class="nav-link " aria-current="page" href="/profile/<?php echo e($product->name); ?>">Gambaran</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/catalogs/<?php echo e($product->name); ?>">Katalog Produk</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="/appointment/<?php echo e($product->name); ?>">Buat Janji</a>
            </li>
          </ul>
    </div>
</div>

    <div class="row ms-5 mt-5 me-5">
        <div class="col">
            <h4>Buat Janji</h4>
            <div class="row mt-3 justify-content-center">
                <div class="card" style="width: 65rem; height: 38rem">
                    <div class="card-body px-4 py-5">
                        <div class="row">
                            <form action="/sendemail">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="umkmName" id="umkmName" value="<?php echo e($product->name); ?>" hidden>
                                <input type="text" name="to_email" id="to_email" value="<?php echo e($product->email); ?>" hidden>
                                <?php if(auth()->user()): ?>
                                <input type="text" name="from_email" id="from_email" value="<?php echo e(auth()->user()->email); ?>" hidden>
                                <?php else: ?>
                                <?php echo e(session()->has('danger')); ?>

                                <?php endif; ?>
                            <h6>Silakan masukkan biodata anda</h6>
                            <table>
                                <tr>
                                    <td>
                                        <div class="mb-3 me-3 ms-2">
                                            <input type="text" class="form-control" id="name" name="name" placeholder="Nama Lengkap" required>
                                          </div>
                                    </td>
                                    <td>
                                        <div class="mb-3 ms-3 me-2">
                                            <input type="text" class="form-control" id="phone" name="phone" placeholder="No. Hp" required>
                                          </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="mb-3 me-3 ms-2">
                                            <input type="email" class="form-control" id="email" name="email" placeholder="Alamat Email" required>
                                          </div>
                                    </td>
                                </tr>
                            </table>

                            <h6>Silakan masukkan detail rapat</h6>
                            <table>
                                <tr>
                                    <td>
                                        <div class="mb-3 me-3 ms-2">
                                            <input type="date" class="form-control" id="date" name="date" placeholder="Tanggal" required>
                                          </div>
                                    </td>
                                    <td>
                                        <div class="mb-3 ms-3 me-2">
                                            <input type="time" class="form-control" id="time1" name="time1" placeholder="Jangka Waktu 1" required>
                                          </div>
                                    </td>
                                    <td class="d-flex align-content-center">sampai</td>
                                    <td>
                                        <div class="mb-3 ms-3 me-2">
                                            <input type="time" class="form-control" id="time2" name="time2" placeholder="Jangka Waktu 2" required>
                                          </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="mb-3 me-3 ms-2">
                                            <input type="text" class="form-control" id="subject" name="subject" placeholder="Perihal" required>
                                          </div>
                                    </td>
                                </tr>
                            </table>

                            <h6>Silakan masukkan pesan anda</h6>
                            <div class="form-floating">
                                <textarea class="form-control" placeholder="Leave a comment here" id="desc" name="desc" style="height: 150px" required></textarea>
                              </div>
                              
                        </div>
                        
                        <div class="d-flex justify-content-center mb-4 mt-4">
                            <button class="btn btn-success" type="submit">Kirim Pesan</button>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
<script>

    document.addEventListener('trix-file-accept', function (e) {
        e.preventDefault();
    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-akhir-3.0\resources\views/layouts/company/appointment.blade.php ENDPATH**/ ?>