

<?php $__env->startSection('body'); ?>

    <div class="row mt-5 ms-5 me-5">
        <div class="col">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                <a class="nav-link " aria-current="page" href="/company-profile">Gambaran</a>
                </li>
                <li class="nav-item">
                <a class="nav-link " href="/company-catalogs">Katalog Produk</a>
                </li>
                <li class="nav-item">
                <a class="nav-link active" href="/company-appointment">Buat Janji</a>
                </li>
            </ul>
        </div>
    </div>

    <div class="row ms-5 mt-5 me-5">
        <div class="col">
            <h4>Buat Janji</h4>
            <div class="row mt-3 justify-content-center">
                <div class="card" style="width: 60rem; height: 35rem">
                    <div class="card-body px-4 py-5">
                        <div class="row">
                            <h6>Silakan masukkan biodata anda</h6>
                            <table>
                                <tr>
                                    <td>
                                        <div class="mb-3 me-3 ms-2">
                                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Nama Lengkap">
                                          </div>
                                    </td>
                                    <td>
                                        <div class="mb-3 ms-3 me-2">
                                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="No. Hp">
                                          </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="mb-3 me-3 ms-2">
                                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Alamat Email">
                                          </div>
                                    </td>
                                </tr>
                            </table>

                            <h6>Silakan masukkan detail rapat</h6>
                            <table>
                                <tr>
                                    <td>
                                        <div class="mb-3 me-3 ms-2">
                                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Tanggal">
                                          </div>
                                    </td>
                                    <td>
                                        <div class="mb-3 ms-3 me-2">
                                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Jangka Waktu Rapat">
                                          </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="mb-3 me-3 ms-2">
                                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Deskripsi Rapat">
                                          </div>
                                    </td>
                                    <td>
                                        <div class="mb-3 ms-3 me-2">
                                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Link Rapat">
                                          </div>
                                    </td>
                                </tr>
                            </table>

                            <h6>Silakan masukkan pesan anda</h6>
                            <div class="form-floating">
                                <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" style="height: 150px"></textarea>
                              </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-akhir\resources\views/layouts/company/appointment.blade.php ENDPATH**/ ?>