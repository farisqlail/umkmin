<nav class="navbar navbar-expand-lg">
    <div class="container">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a class="navbar-brand" href="/">
            <img src="<?php echo e(asset('/assets/UMKM.png')); ?>" alt="" >
          </a>
    
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 h5">
          <?php if(auth()->guard()->check()): ?>
          <?php if(auth()->user()->role == 'umkm'): ?>
          <li class="nav-item border-end">
            <a class="nav-link"href="/dashboard">UMKM</a>
          </li>
          <?php else: ?>
          <li class="nav-item border-end visually-hidden">
            <a class="nav-link"href="/dashboard">UMKM</a>
          </li>
          <?php endif; ?>
          <?php else: ?>
          <li class="nav-item border-end visually-hidden">
            <a class="nav-link"href="/dashboard">UMKM</a>
          </li>
          <?php endif; ?>
          <li class="nav-item border-end">
            <a class="nav-link"href="/">Beranda</a>
          </li>
          <li class="nav-item border-end">
            <a class="nav-link" href="/about">Tentang Kami</a>
          </li>
          <?php if(auth()->guard()->check()): ?>
          <form action="/keluar" method="post">
            <?php echo csrf_field(); ?>
          <li class="nav-item">
            <a class="" style="text-decoration: none;"><button class="nav-link btn btn-link mt-1 ms-2" type="submit" style="padding: 0;">Keluar</button></a>
          </li>
          </form>
          <?php else: ?>
          <li class="nav-item border-end">
            <a class="nav-link" href="/login">Masuk</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/register">Daftar</a>
          </li>
          <?php endif; ?>
        </ul>
       
      </div>
    </div>
  </nav><?php /**PATH C:\Users\krisn\Downloads\coba-akhir-2.0\coba-akhir-2.0\resources\views/partials/navbar.blade.php ENDPATH**/ ?>