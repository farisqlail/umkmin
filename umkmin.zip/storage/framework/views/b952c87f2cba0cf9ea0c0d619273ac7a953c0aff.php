<h1>Forget Password Email</h1>
   
You can reset password from bellow link:
<a class="btn btn-primary" href="<?php echo e(route('reset.password.get', $token)); ?>">Reset Password</a><?php /**PATH C:\django\coba111\resources\views/email/forgetPassword.blade.php ENDPATH**/ ?>