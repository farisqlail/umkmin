

<?php $__env->startSection('container'); ?>

<?php if(session()->has('status') && session('status') == "user-updated"): ?>
<script type='text/javascript'> 
      Swal.fire({
        text: 'Profile User Berhasil Diubah',
        icon: 'success',
        })
</script>
<?php elseif(session()->has('status') && session('status') == "umkm-updated"): ?>
<script type='text/javascript'> 
Swal.fire({
        text: 'Profile UMKM Berhasil!!!',
        icon: 'success',
        })
</script>
<?php endif; ?>  

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    
    <h1 class="h2">Selamat Datang, <?php echo e(auth()->user()->name); ?></h1>
  </div>
  <a href="/" class="btn btn-primary btn-lg">Kembali ke Menu Awal</a>
<br>
  <?php if($umkm->foto != null): ?>
  <img class="mt-3" src="<?php echo e(asset('storage/' . $umkm->foto->photo_name)); ?>" alt="" style="justify-content: center">
  <?php else: ?>
  <img class="mt-3" src="http://source.unsplash.com/300x200?company" alt="" style="justify-content: center">
  <?php endif; ?>
  <button class="btn btn-primary ms-5 editProfile" id="modalEditUmkm" data-bs-toggle="modal" data-id="<?php echo e(auth()->user()->id); ?>" data-bs-target="#exampleModalUmkm">Edit Profile</button>
  <div class="row mt-4 fs-5">
        <p class="col-2">Nama UMKM</p>
        <p class="col-9"> : <?php echo e($umkm->name); ?></p>
      
        <p class="col-2">Email UMKM</p>
        <p class="col-9"> : <?php echo e($umkm->email); ?></p>
  
        <p class="col-2">No Telp</p>
        <p class="col-9"> : <?php echo e($umkm->telp); ?></p>
  
        <p class="col-2">Alamat</p>
        <p class="col-9"> : <?php echo e($umkm->address); ?></p>

        <p class="col-2">Website</p>
        <p class="col-9"> : <?php echo e($umkm->website); ?></p>

        <p class="col-2">Sektor Bisnis</p>
        <p class="col-9"> : <?php echo e($umkm->business_sector); ?></p>
     
        <p class="col-2">Deskripsi UMKM</p>
        <p class="col-9"> : <?php echo e($umkm->desc); ?></p>

  </div>

  <div class="modal fade" id="exampleModalUmkm" tabindex="-1" aria-labelledby="judulModal" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="judulModal">Edit Profile</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="/dashboard/update" method="post" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" class="form-control" id="id_umkm" name="id_umkm" value="<?php echo e($umkms->id); ?>" >
            <input type="text" class="form-control" id="photo_id" name="photo_id" value="<?php echo e($umkm->photo_id); ?>" hidden>
            <input type="text" class="form-control" id="role" name="role" value="<?php echo e($umkm->role); ?>" hidden>
            <div class="modal-body">
                <div class="">
                  <label for="name" class="col-form-label">Nama Umkm</label>
                  <input type="text" class="form-control" id="name" name="name" value="" required>
                </div>
                <div class="">
                  <label for="email" class="col-form-label">Email</label>
                  <input type="text" class="form-control" id="email" name="email" value="" required>
                </div>
                <div class="">
                  <label for="telp" class="col-form-label">No Telp</label>
                  <input type="text" class="form-control" id="telp" name="telp" value="" required>
                </div>
                <div class="">
                  <label for="address" class="col-form-label">Alamat</label>
                  <input type="text" class="form-control" id="address" name="address" value="" required>
                </div>
                <div class="">
                  <label for="website" class="col-form-label">Website</label>
                  <input type="text" class="form-control" id="website" name="website" value="" required>
                </div>
                <div class="">
                  <label for="business_sector" class="col-form-label">Sektor Bisnis</label>
                  <input type="text" class="form-control" id="business_sector" name="business_sector" value="" required>
                </div>
                <div>
                  <label for="photo_name" class="form-label">Gambar Produk</label>
                  <img class="img-preview img-fluid mb-3 col-sm-5">
                  <input class="form-control <?php $__errorArgs = ['photo_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="photo_name" name="photo_name"
                      onchange="previewImage()">
                  <?php $__errorArgs = ['photo_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback">
                      <?php echo e($message); ?>

                  </div>
                  <script type='text/javascript'> 
                    Swal.fire({
                            text: 'Ukuran gambar max 1024 kilobytes',
                            icon: 'warning',
                            })
                    </script>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="">
                  <label for="desc" class="form-label mt-1">Deskripsi Produk</label>
                  <textarea class="form-control" name="desc" id="desc" cols="30" rows="10"></textarea>
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary">Edit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  
<script>
  const title = document.querySelector('#prod_name');
  const slug = document.querySelector('#slug');

  title.addEventListener('change', function () {
      fetch('/dashboard/posts/checkSlug?prod_name=' + title.value)
          .then(response => response.json())
          .then(data => slug.value = data.slug)
  });


  document.addEventListener('trix-file-accept', function (e) {
      e.preventDefault();
  });

  function previewImage() {
      const image = document.querySelector('#photo_name');
      const imgPreview = document.querySelector('.img-preview');

      imgPreview.style.display = 'block';

      const oFReader = new FileReader();
      oFReader.readAsDataURL(image.files[0]);

      oFReader.onload = function (oFREvent) {
          imgPreview.src = oFREvent.target.result;
      }
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\django\coba111\resources\views/dashboard/index.blade.php ENDPATH**/ ?>