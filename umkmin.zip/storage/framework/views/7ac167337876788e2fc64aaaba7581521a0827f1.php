

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Email yang Masuk, <?php echo e(auth()->user()->name); ?></h1>
  </div>

  <?php if(session()->has('success')): ?>
  <div class="alert alert-success col-lg-8" role="alert">
    <?php echo e(session('success')); ?>

  </div>
  <?php endif; ?>

  <div class="table-responsive col-lg-8">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Dari</th>
          <th scope="col">Mengenai</th>
          <th scope="col">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($mail->from_email); ?></td>
          <td><?php echo e($mail->subject); ?></td>
          <td>
                <a href="/dashboard/mailA/<?php echo e($mail->id); ?>" class="badge bg-success"><span data-feather="check"></span></a>
                <a href="/dashboard/mailR/<?php echo e($mail->id); ?>" class="badge bg-danger"><span data-feather="x-circle"></span></a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-akhir-3.0\resources\views/dashboard/posts/email.blade.php ENDPATH**/ ?>