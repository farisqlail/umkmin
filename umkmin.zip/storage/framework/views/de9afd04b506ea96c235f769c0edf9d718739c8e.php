

<?php $__env->startSection('body'); ?>

    <input type="text" id="idUmkm" name="idUmkm" value="<?php echo e($umkm->name); ?>" hidden>
    <div class="row mt-5 ms-5 me-5">
        <div class="col">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="/profile/<?php echo e($umkm->name); ?>">Gambaran</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/catalog/<?php echo e($umkm->name); ?>">Katalog Produk</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/appointment/<?php echo e($umkm->name); ?>">Buat Janji</a>
                </li>
              </ul>
        </div>
    </div>

    <div class="row ms-5 mt-5 me-5">
        <div class="col">
            <h4>Tentang Perusahaan</h4>
            <p class="my-3 fs-5 " style="text-align: justify;">
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur dicta placeat fugiat harum velit labore quo ipsa iusto veritatis laborum cumque qui similique, temporibus doloremque? Porro quas inventore, architecto possimus dolores aliquam unde saepe asperiores provident natus pariatur alias explicabo sequi illo vitae aspernatur autem magni quibusdam sed.
                <br>
                <br>
                Voluptates facilis deserunt eius sit vel. Harum, nemo. Veniam odit aut natus assumenda laborum iste alias repudiandae accusantium magnam, in, corrupti quos consectetur quo dolorum architecto? Voluptates molestias fuga odio numquam ipsum dolorem cumque doloribus distinctio sapiente, pariatur ex laboriosam neque quibusdam architecto commodi minus facere eos harum nemo provident voluptatem exercitationem!
            </p>
        </div>
    </div>

    <hr class="ms-5 me-5 mt-5">

    <div class="row ms-5 mt-5 me-5">
        <div class="col">
            <h4>Produk Terpopuler</h4>
            <div class="row my-3 fs-5 ">
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title fw-bold hurufbesar">Pintu</h5>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 20</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title fw-bold hurufbesar">Pintu</h5>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 04</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title fw-bold hurufbesar">Pintu</h5>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 11</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title fw-bold hurufbesar">Pintu</h5>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 16</p>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\krisn\Downloads\coba-akhir-2.0\coba-akhir-2.0\resources\views/layouts/company/profile.blade.php ENDPATH**/ ?>