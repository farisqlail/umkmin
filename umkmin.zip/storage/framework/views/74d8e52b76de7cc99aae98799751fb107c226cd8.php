<?php echo e($slot); ?>

<?php /**PATH C:\laravel\coba-akhir-2.0\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>