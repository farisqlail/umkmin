

<?php $__env->startSection('container'); ?>


<div class="d-flex  flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Hai Admin</h1>
  </div>

  <?php if(session()->has('success')): ?>
  <div class="alert alert-success col-lg-8" role="alert">
    <?php echo e(session('success')); ?>

  </div>
  <?php elseif(session()->has('danger')): ?>
  <div class="alert alert-danger col-lg-8" role="alert">
    <?php echo e(session('danger')); ?>

  </div>
  <?php endif; ?>

  <div class="table-responsive col-lg-8">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nama</th>
          <th scope="col">Email</th>
          <th scope="col">Role</th>
          <th scope="col">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($user->name); ?></td>
          <td><?php echo e($user->email); ?></td>
          <td><?php echo e($user->role); ?></td>
          <td>
              <form action="/manajemen/users/status" method="post" class="d-inline">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" id="id" name="id" value="<?php echo e($user->id); ?>">
                <button class="badge bg-danger border-0" onclick="return confirm('Menonaktifkan user?')"><span data-feather="x-circle"></span></button>
              </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center">
      <?php echo e($users->links()); ?>

  </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-akhir-4.0\resources\views/dashboard/posts/user.blade.php ENDPATH**/ ?>