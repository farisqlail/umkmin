<table>
    <tr>
        <td colspan="3">Nama</td>
        <td>   &nbsp;&nbsp;:&nbsp;&nbsp; <?php echo e($email_desc['name']); ?></td>
    </tr>
    <tr>
        <td colspan="3">Telp</td>
        <td>   &nbsp;&nbsp;:&nbsp;&nbsp; <?php echo e($email_desc['phone']); ?></td>
    </tr>
    <tr>
        <td colspan="3">Email</td>
        <td>   &nbsp;&nbsp;:&nbsp;&nbsp; <?php echo e($email_desc['email']); ?></td>
    </tr>
    <tr>
        <td colspan="3">Tanggal</td>
        <td>   &nbsp;&nbsp;:&nbsp;&nbsp; <?php echo e($email_desc['date']); ?></td>
    </tr>
    <tr>
        <td colspan="3">Waktu</td>
        <td>   &nbsp;&nbsp;:&nbsp;&nbsp; <?php echo e($email_desc['time1']); ?> - <?php echo e($email_desc['time2']); ?></td>
    </tr>
    <tr>
        <td colspan="3">Pesan</td>
        <td>   &nbsp;&nbsp;:&nbsp;&nbsp; <?php echo e($email_desc['desc']); ?></td>
    </tr>
</table><?php /**PATH C:\laravel\coba-akhir-4.0\resources\views/layouts/mail.blade.php ENDPATH**/ ?>