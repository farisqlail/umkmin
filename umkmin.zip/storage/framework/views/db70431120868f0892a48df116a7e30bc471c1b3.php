

<?php $__env->startSection('container'); ?>

<?php if(session()->has('success')): ?>

<div class="alert alert-succes alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>

<div class="container">
    <div class="row text-center">
        <div class="bg-image text-white" style="background-image: url('/assets/bg1.png'); height:70vh">
            <div class="mx-auto" >
            <div class="mt-5">
                <h1>Kembangkan Bisnis Anda Bersama UMKM.IN</h1>
                <h6 class="mt-5" >Temukan berbagai layanan digital di UMKM.IN, mulai dari pembaruan profil perusahaan,
                    promosi produk, hingga layanan digital menarik lainnya. Jadi, apa yang anda tunggu? Mari bergabung
                    dengan kami</h5>
            </div>
            <form class="row g-1 justify-content-center mt-5">
                <div class="col-3">
                    <label for="cariPerusahaan" class="visually-hidden"></label>
                    <input type="text" class="form-control" id="cariPerusahaan"
                        placeholder="Cari perusahaan atau produk">
                </div>
                <div class="col-2">
                    <label for="cariLokasi" class="visually-hidden"></label>
                    <input type="text" class="form-control" id="cariLokasi" placeholder="Lokasi">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-success mb-3">Cari</button>
                </div>
            </form>
        </div>
        </div>
        

    </div>

    <div class="row align-items-center bg-nyala ">
        <div class="col">
            <div class="row mt-4">
                <div class="col-2">
                    <img src="<?php echo e(asset('/assets/claim.png')); ?>" alt="">
                </div>
                <div class="col-9">
                    <h5>Klaim Informasi Bisnis Anda</h5>
                    <p>Kami akan mengirimkan informasi bisnis anda kepada anda melalui email</p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="row mt-4">
                <div class="col-2">
                    <img src="<?php echo e(asset('/assets/megaphone.png')); ?>" alt="">
                </div>
                <div class="col-9">
                    <h5>Promosikan Bisnis Anda</h5>
                    <p>Kami akan mengirimkan promosi bisnis anda kepada anda melalui email</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-5 mb-5">
        <div class="col">
            <h3 class="text-center mb-5">Daftar Perusahaan</h3>
            <div class="row justify-content-center ">
                <div class="row">
                    <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="text" id="idUmkm" name="idUmkm" value="<?php echo e($umkm->id); ?>" hidden>
                    <div class="col-sm-3 mb-4">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                            <div class="card-body">
                                <a href="/profile/<?php echo e($umkm->name); ?>" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar"><?php echo e($umkm->name); ?></h5></a>
                                <p class="card-text fw-light hurufkecil">Jl. Raya Kediri - Nganjuk, Santren Lor</p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                <a href="/companies" class="mt-3 text-end" style="text-decoration: none">Lihat Lebih Banyak</a>
            </div>
        </div>
    </div>

    <div class="row mt-5 mb-5 bg-nyala">
        <div class="col">
            <h3 class="text-center mb-5 mt-5">Daftar Produk</h3>
            <div class="row justify-content-center ">
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" id="prod" name="prod" value="<?php echo e($prod->id); ?>" >
                    <input type="hidden" id="idUmkm" name="idUmkm" value="<?php echo e($prod->user_id); ?>" >
                    <div class="col-sm-3 mb-4">
                        <div class="card">
                            <img src="<?php echo e(asset('storage/' . $prod->photo->photo_name)); ?>" class="card-img-top" alt="..." width="300" height="200">
                            <div class="card-body">
                                <a href="/catalog/<?php echo e($prod->slug); ?>" class="text-black" style="text-decoration: none;"><h5 class="card-title fw-bold hurufbesar"><?php echo e($prod->prod_title); ?></h5></a>
                                <p class="card-text fw-light hurufkecil"><?php echo e($prod->prod_name); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                </div>
                <a href="/products" class="mt-3 mb-3 text-end" style="text-decoration: none">Lihat Lebih Banyak</a>
            </div>
        </div>
    </div>

    <div class="row mt-5 mb-5">
        <div class="col">
            <h3 class="text-center mb-5">Berita Terbaru</h3>
            <div class="row justify-content-center ">
                <div class="row">

                    <div class="col-sm-4">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?news" class="card-img-top" alt="...">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <a href="" style="text-decoration: none">April 15, 2022</a>
                                    <a href="" style="text-decoration: none">UMKM.IN News</a>
                                </div>
                                <p class="card-text fw-bold hurufbesar">Mantap! Tembus Rp 156M, Komoditas Ikan Bali
                                    diminati di Amerika
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?news" class="card-img-top" alt="...">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <a href="" style="text-decoration: none">April 15, 2022</a>
                                    <a href="" style="text-decoration: none">UMKM.IN News</a>
                                </div>
                                <p class="card-text fw-bold hurufbesar">Ini 'Pahlawan' yang Bikin Neraca Dagang RI
                                    Surplus 23 Kali Beruntun
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <img src="http://source.unsplash.com/300x200?news" class="card-img-top" alt="...">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <a href="" style="text-decoration: none">April 15, 2022</a>
                                    <a href="" style="text-decoration: none">UMKM.IN News</a>
                                </div>
                                <p class="card-text fw-bold hurufbesar">Jajanan Lokal RI Bisa Tembus Pasar Ekspor,
                                    Caranya?
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="" class="mt-3 text-end" style="text-decoration: none">Lihat Lebih Banyak</a>
            </div>
        </div>
    </div>


    


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\krisn\Downloads\coba-akhir-2.0\coba-akhir-2.0\resources\views/home.blade.php ENDPATH**/ ?>