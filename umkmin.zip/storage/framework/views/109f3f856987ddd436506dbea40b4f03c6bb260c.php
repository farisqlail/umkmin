<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('/assets/Logo/UMKM.png')); ?>" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <title>Daftar Akun User UMKM.IN</title>
</head>

<body>
    <?php if(session()->has('danger')): ?>
<div class="alert alert-danger col-lg-8" role="alert">
  <?php echo e(session('danger')); ?>

</div>
<?php endif; ?>
    <div class="container">
        <div class="img-umkm d-flex justify-content-center">
            <img src="<?php echo e(asset('/assets/Logo/UMKM.png')); ?>" alt="" srcset="" class="mt-3">
        </div>
        <div class="row">
            <div class="col">
                <div class="img-register-actor">
                    <img src="<?php echo e(asset('/assets/Register/image 1.png')); ?>" alt="" srcset="" class="mt-5">
                </div>
                <h3 class="mt-5 text-end"><b>Mari Bergabung Bersama UMKM.INUntuk Kemajuan Bisnis Anda</b></h3>
            </div>
            <div class="col-1">
                <div class="garis mt-5"></div>
            </div>
            <div class="col">
                <div class="kotak-registeractor mt-5">
                    <div class="container-medium mx-auto pt-4">
                        <h3 class="mt-2"><b>Daftar Sebagai Mitra</b></h3>
                        <form action="/regismitra" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="role" id="role" value="umkm" hidden>
                            <div class="form-floating mt-2">
                                <input type="text" class="form-control rounded-top <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="name" id="name" placeholder="Nama lengkap" required value="<?php echo e(old('nama')); ?>">
                                <label for="name">Name</label>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating mt-2">
                                <input type="text" class="form-control rounded-top <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="username" id="username" placeholder="Username" required
                                    value="<?php echo e(old('username')); ?>">
                                <label for="username">Username</label>
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating mt-2">
                                <input type="email" class="form-control rounded-top <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email" id="email" placeholder="Email" required value="<?php echo e(old('email')); ?>">
                                <label for="email">Email</label>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating mt-2">
                                <input type="password" class="form-control rounded-top <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="password" id="password" placeholder="Kata sandi" required
                                    value="<?php echo e(old('password')); ?>">
                                <label for="password">Password</label>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating mt-2">
                                <input type="password"
                                    class="form-control rounded-top <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="password_confirmation" id="password_confirmation"
                                    placeholder="Konfirmasi kata sandi" required value="<?php echo e(old('password_confirmation')); ?>">
                                <label for="name">Konfirmasi password</label>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-sm-10 mt-3 mx-auto">
                                <div class="d-grid gap-2 col-6 mx-auto">
                                    <button class="btn btn-danger" type="submit"><b>Buat Akun</b></button>
                                </div>
                            </div>
                        </form>
                        <div class="mb-3 col-sm-8 mx-auto">
                            <p class="text-center"><b>Kembali ? </b><a href="/register" class="text-danger"><b>Klik
                                        Disini</b></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\laravel\coba-akhir\resources\views/user/mitra/pages/register_mitra.blade.php ENDPATH**/ ?>