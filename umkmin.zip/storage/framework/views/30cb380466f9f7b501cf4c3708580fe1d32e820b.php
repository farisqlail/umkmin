

<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="row ms-4" >
        <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2"
                    aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active" data-bs-interval="10000">
                    <img class="opacity-75" src="http://source.unsplash.com/1200x300?company" class="d-block w-100"
                        alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>First slide label</h5>
                        <p>Some representative placeholder content for the first slide.</p>
                    </div>
                </div>
                <div class="carousel-item" data-bs-interval="2000">
                    <img class="opacity-75" src="http://source.unsplash.com/1200x300?product" class="d-block w-100"
                        alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Second slide label</h5>
                        <p>Some representative placeholder content for the second slide.</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="opacity-75" src="http://source.unsplash.com/1200x300?market" class="d-block w-100"
                        alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Third slide label</h5>
                        <p>Some representative placeholder content for the third slide.</p>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

    <div class="row mt-5 px-5">
        <div class="col-3">
            <div class="row">
                <h3 class="fw-bold mb-4">Filter</h3>
                <div class="card border-secondary mb-3" style="max-width: 18rem;">
                    <div class="card-header fw-bold">Kategori</div>
                    <div class="card-body text-secondary">
                        <a href="" class="card-text sektor" style="text-decoration: none">Pertanian</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Seni dan Kerajinan</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Produk Kimia</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Elektronik</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Layanan Keuangan</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Teknologi Keuangan</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Mabel</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Permainan</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Kesehatan</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Kecantikan</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Industrial</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Perhiasan</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Produk Logam</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Tekstil, Garmen, dan Batik</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Produk Tembakau</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Suku Cadang Otomotif</a>
                        <br>
                    </div>
                </div>

                <div class="card border-secondary mb-3" style="max-width: 18rem;">
                    <div class="card-header fw-bold">Wilayah</div>
                    <div class="card-body text-secondary">
                        <a href="" class="card-text sektor" style="text-decoration: none">Jawa Timur (122)</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Jawa Barat (98)</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Jawa Tengah (216)</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Banten (110)</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">DKI Jakarta (76)</a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">DI Yogyakarta (85) </a>
                        <br>
                        <a href="" class="card-text sektor" style="text-decoration: none">Bali (105)</a>
                        <br>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-9">
            <h3 class="fw-bold mb-4 ms-3">Perusahaan</h3>
            <form action="/companies" class="row ms-2">
                <div class="d-flex">
                    <div class="col-11">
                        
                        <label for="cariPerusahaan" class="visually-hidden"></label>
                        <input type="text" class="form-control" placeholder="Search..." name="search" value="<?php echo e(request('search')); ?>">  
                    </div>
                    <div class="ms-2">
                        <button type="submit" class="btn btn-success mb-3"><span data-feather="search"></span></button>
                    </div>
                </div>
            </form>
            <div class="row ms-2">
                <?php if($umkms->count()): ?>
                <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?company" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title fw-bold hurufbesar"><?php echo e($umkm->name); ?></h5>
                            <p class="card-text fw-light hurufkecil"><?php echo e($umkm->address); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <?php endif; ?>
                

            </div>
            <nav aria-label="Page navigation example">
                <ul class="pagination justify-content-center">
                    <li class="page-item disabled">
                        <a class="page-link">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-akhir-2.0\resources\views/layouts/company/index.blade.php ENDPATH**/ ?>