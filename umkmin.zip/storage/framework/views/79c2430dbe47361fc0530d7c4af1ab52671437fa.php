

<?php $__env->startSection('body'); ?>

    <div class="row mt-5 ms-5 me-5">
        <div class="col">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                <a class="nav-link " aria-current="page" href="/company-profile">Gambaran</a>
                </li>
                <li class="nav-item">
                <a class="nav-link active" href="/company-catalogs">Katalog Produk</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/company-appointment">Buat Janji</a>
                </li>
            </ul>
        </div>
    </div>

    <div class="row ms-5 mt-5">
        <div class="col-auto">
            <div class="d-flex">
                <div class="col">
                    <div class="card" style="width: 12rem;">
                        <div class="card-body">
                            <img src="http://source.unsplash.com/300x200?doors" alt="" width="160" height="200">
                        </div>
                    </div>
                </div>
                <div class="row ms-4 lh-sm">
                    <div class="col-auto">
                        <h4>Pintu Ukiran - Model 11</h4>
                        <table>
                            <tr>
                                <td>Kondisi</td>
                                <td>&nbsp;: Baru</td>
                            </tr>
                            <tr>
                                <td>Berat</td>
                                <td>&nbsp;: 1.5 Kg</td>
                            </tr>
                            <tr>
                                <td>Kategori</td>
                                <td>&nbsp;: Pintu</td>
                            </tr>
                        </table> 
                        
                        <p class="me-5 mt-4" style="text-align: justify;">
                            Pintu Fara dengan bangga terbuat dari bahan kayu solid berkualitas tinggi. Penggunaan kayu solid akan memberi Anda kehangatan dan eksklusivitas yang tidak dapat ditandingi oleh bahan buatan. Selain itu, Fara mengkhususkan diri dalam membuat ukiran kayu yang indah di setiap pintu kami. Ukiran kayu menambah nilai tambah dalam hal keanggunan dan aspek budaya yang unik bagi setiap konsumen kami. 
                        </p>
                    </div>
                    
                </div>

            </div>
        </div>
    </div>


    <hr class="ms-5 me-5 mt-5">

    <div class="row ms-5 mt-5 me-5">
        <div class="col">
            <h4>Katalog Produk</h4>
            <div class="row my-3 fs-5 ">
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 20</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 04</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 11</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 16</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-uiux\resources\views/layouts/company/catalog.blade.php ENDPATH**/ ?>