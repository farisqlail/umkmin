<nav class="navbar navbar-expand-lg">
    <div class="container">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a class="navbar-brand" href="/">
            <img src="<?php echo e(asset('/assets/UMKM.png')); ?>" alt="" >
          </a>
    
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 h5">
          <li class="nav-item visually-hidden">
            <a class="nav-link"href="#">UMKM</a>
          </li>
          <li class="nav-item">
            <a class="nav-link"href="/">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/about">Tentang Kami</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Masuk</a>
          </li>
          <li class="nav-item">
              <a class="nav-link">/</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Daftar</a>
          </li>
        </ul>
       
      </div>
    </div>
  </nav><?php /**PATH C:\laravel\coba-uiux\resources\views/partials/navbar.blade.php ENDPATH**/ ?>