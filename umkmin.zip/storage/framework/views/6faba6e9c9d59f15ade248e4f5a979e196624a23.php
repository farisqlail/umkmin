<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('/assets/Logo/UMKM.png')); ?>" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <title>Halaman Masuk User UMKM.IN</title>
</head>

<body>
    <div class="container" style="height: 100vh;">
        <div class="row" style="height: 100vh;">
            <div class="col d-flex align-items-center" style="height: 100vh;">
                <img src="<?php echo e(asset('/assets/Logo/UMKM.png')); ?>" alt="" srcset="" class="img-login ">
            </div>
            <div class="col d-flex align-items-center" style="height: 100vh;">
                <div class="kotak-login d-flex align-items-center">
                    <div class="col-12">
                        <h1 class="text-center"><b>Masuk</b></h1>
                        <div class="mx-5">
                            <form action="/masuk" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-floating mt-2">
                                    <input type="text"
                                        class="form-control rounded-top <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="username" id="username" placeholder="Username" required
                                        value="<?php echo e(old('username')); ?>">
                                    <label for="username">Username</label>
                                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-floating mt-2">
                                    <input type="password"
                                        class="form-control rounded-top <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="password" id="password" placeholder="Password" required
                                        value="<?php echo e(old('password')); ?>">
                                    <label for="password">Password</label>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col mt-2">
                                    <p class="text-end"><a href="/forgot" class="text-dark"><b>Lupa kata Sandi?</b></a></p>
                                </div>
                                <div class="mb-3 col-sm-8 mt-5 mx-auto">
                                    <div class="d-grid gap-2 col-6 mx-auto">
                                        <button class="btn btn-danger" type="submit"><b>Masuk</b></button>
                                    </div>
                                </div>

                        </form>
                        
                    </div>
                        <div class="mb-3 col-sm-8 mx-auto">
                            <p class="text-center"><b> Baru di UMKM.IN ? </b><a href="/register" class="text-danger"
                                    style="text-decoration: none;"><b>Daftar</b></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous">
    </script>
</body>

</html><?php /**PATH C:\laravel\coba-akhir\resources\views/auth/pages/login.blade.php ENDPATH**/ ?>