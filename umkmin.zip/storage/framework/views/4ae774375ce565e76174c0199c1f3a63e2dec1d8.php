<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('/assets/icon-web.png')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

    <title>Lupa Kata Sandi User UMKM.IN</title>
</head>
<body>
    <div class="container">
        <div class="img-umkm d-flex justify-content-center">
            <img src="<?php echo e(asset('/assets/Logo/UMKM.png')); ?>" alt="" srcset="" class="mt-3">
        </div>
        <div class="d-flex justify-content-center mt-4">
            <div class="kotak-forgot">
                <h4 class="mt-5 text-center"><b>Lupa Kata Sandi ?</b></h4>
                <p class="mt-2 text-center">Dimohon mengisikan alamat email yang sudah <br> terdaftar pada akun UMKM.IN untuk melakukan <br> perubahan kata sandi pada akun anda. Anda akan <br> menerima melalui email anda tentang petunjuk <br> dan kode kemanan.</p>
                <?php if(Session::has('message')): ?>
                <div class="alert alert-success" role="alert">
                   <?php echo e(Session::get('message')); ?>

                </div>
                <?php endif; ?>
                <form action="/forget-password-ps" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="container col-11">
                        <h3 class="mt-5"><b>Masukkan Data Anda</b></h3>
                        <input type="email" class="form-control mt-3" id="email_address" name="email" placeholder="Masukkan Alamat Email Anda">
                    </div>
                    <div class="d-grid gap-2 col-4 p-3 mx-auto mt-5">
                        <button type="submit" class="btn btn-danger p-3">Ubah kata sandi</button>
                    </div>
                </form>
                    <div class="mb-3 col-sm-8 mx-auto">
                        <p class="text-center"><b> Atau Masuk Kembali </b><a href="/login" class="text-danger"><b>Klik Disini</b></a></p>
                    </div>
            </div>
        </div>

    </div>
</body>
</html><?php /**PATH C:\django\coba111\resources\views/auth/pages/forgot.blade.php ENDPATH**/ ?>