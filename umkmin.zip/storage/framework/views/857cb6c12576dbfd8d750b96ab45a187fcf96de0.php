<?php echo e($slot); ?>

<?php /**PATH C:\django\umkmin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>