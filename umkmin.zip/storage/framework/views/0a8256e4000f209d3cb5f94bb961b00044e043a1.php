

<?php $__env->startSection('body'); ?>
    <div class="row mt-5 ms-5 me-5">
        <div class="col">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link " aria-current="page" href="/profile/<?php echo e($products->username); ?>">Gambaran</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="/catalog/<?php echo e($products->name); ?>">Katalog Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/appointment/<?php echo e($products->name); ?>">Buat Janji</a>
                </li>
            </ul>
        </div>
    </div>

    <div class="row ms-5 mt-5">
        <div class="col-auto">
            <div class="d-flex">
                
                <div class="col">
                    <div class="card" style="width: 12rem;">
                        <div class="card-body">
                            <img src="<?php echo e(asset('storage/' . $products->photo_name)); ?>" alt="" width="160" height="200">
                        </div>
                    </div>
                </div>
                <div class="row ms-4 lh-sm">
                    <div class="col-auto">
                        <h4><?php echo e($products->prod_name); ?></h4>
                        <table>
                            <tr>
                                <td>Brand</td>
                                <td>&nbsp;: <?php echo e($products->prod_title); ?></td>
                            </tr>
                            <tr>
                                <td>Kategori</td>
                                <td>&nbsp;: <?php echo e($products->category_name); ?></td>
                            </tr>
                        </table>

                        <p class="me-5 mt-4" style="text-align: justify;">
                            <?php echo e($products->prod_desc); ?>

                        </p>
                    </div>

                </div>

            </div>
        </div>
    </div>


    <hr class="ms-5 me-5 mt-5">

    <div class="row ms-5 mt-5 me-5">
        <div class="col">
            <h4>Katalog Produk</h4>
            <div class="row my-3 fs-5 ">

                

            </div>
        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.company.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\krisn\Downloads\coba-akhir-2.0\coba-akhir-2.0\resources\views/layouts/company/catalog.blade.php ENDPATH**/ ?>