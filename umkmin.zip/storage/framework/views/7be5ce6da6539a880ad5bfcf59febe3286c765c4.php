

<?php $__env->startSection('body'); ?>

<div class="row mt-5 ms-5 me-5">
    <div class="col">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link " aria-current="page" href="/profile/<?php echo e($product->name); ?>">Gambaran</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="/catalog/<?php echo e($product->name); ?>">Katalog Produk</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/appointment/<?php echo e($product->name); ?>">Buat Janji</a>
            </li>
        </ul>
    </div>
</div>

    <hr class="ms-5 me-5 mt-5">

    <div class="row ms-5 mt-5 me-5">
        <div class="col">
            <h4>Katalog Produk</h4>
            <div class="row my-3 fs-5 ">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-3 mb-3">
                        <div class="card">
                            <img src="<?php echo e(asset('storage/' . $prod->photo_name)); ?>" class="card-img-top" alt="..."
                                width="300" height="200">
                            <div class="card-body">
                                <a href="/catalog/<?php echo e($prod->slug); ?>" class="text-black" style="text-decoration: none;">
                                    <h5 class="card-title fw-bold hurufbesar"><?php echo e($prod->prod_title); ?></h5>
                                </a>
                                <p class="card-text fw-light hurufkecil"><?php echo e($prod->prod_name); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-akhir-3.0\resources\views/layouts/company/catalogs.blade.php ENDPATH**/ ?>