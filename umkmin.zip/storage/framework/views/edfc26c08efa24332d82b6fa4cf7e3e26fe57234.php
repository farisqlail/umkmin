<?php echo e($slot); ?>

<?php /**PATH C:\laravel\coba-akhir-3.0\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>