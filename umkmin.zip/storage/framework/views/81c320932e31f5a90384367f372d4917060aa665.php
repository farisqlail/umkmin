

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Produk Saya, <?php echo e(auth()->user()->name); ?></h1>
  </div>

  <?php if(session()->has('status') && session('status') == "product-created"): ?>
        <script type='text/javascript'> 
              Swal.fire({
                text: 'Produk Berhasil Ditambahkan',
                icon: 'success',
                })
        </script>
    <?php elseif(session()->has('status') && session('status') == "product-updated"): ?>
    <script type='text/javascript'> 
        Swal.fire({
                text: 'Produk Berhasil Diubah',
                icon: 'success',
                })
    </script>
    <?php elseif(session()->has('status') && session('status') == "product-destroy"): ?>
    <script type='text/javascript'> 
        Swal.fire({
                text: 'Produk Berhasil Dihapus',
                icon: 'success',
                })
    </script>
    <?php endif; ?>  

  <div class="table-responsive col-lg-8">
    <a href="/dashboard/posts/create" class="btn btn-primary mb-3">Buat produk baru</a>
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nama Produk</th>
          <th scope="col">Kategori</th>
          <th scope="col">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($prod->prod_name); ?></td>
          <td><?php echo e($prod->category->category_name); ?></td>
          <td>
              <a href="/dashboard/posts/<?php echo e($prod->slug); ?>" class="badge bg-info"><span data-feather="eye"></span></a>
              <a href="/dashboard/posts/<?php echo e($prod->slug); ?>/edit" class="badge bg-warning"><span data-feather="edit"></span></a>
              <form action="/dashboard/posts/<?php echo e($prod->slug); ?>" method="post" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button class="badge bg-danger border-0" onclick="return confirm('Yakin hapus?')"><span data-feather="x-circle"></span></button>
              </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-akhir-4.0\resources\views/dashboard/posts/index.blade.php ENDPATH**/ ?>