

<?php $__env->startSection('container'); ?>


<div class="d-flex  flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Hai Admin</h1>
  </div>

  <?php if(session()->has('success')): ?>
  <div class="alert alert-success col-lg-8" role="alert">
    <?php echo e(session('success')); ?>

  </div>
  <?php elseif(session()->has('danger')): ?>
  <div class="alert alert-danger col-lg-8" role="alert">
    <?php echo e(session('danger')); ?>

  </div>
  <?php endif; ?>

  <div class="table-responsive col-lg-8">
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModalCreate" data-bs-whatever="@mdo">Tambah Kategori Baru</button>
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Kategori</th>
          <th scope="col">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($category->category_name); ?></td>
          <td>
              <a href="" class="badge bg-warning editCategory" id="modalEditCategory" data-bs-toggle="modal" data-id="<?php echo e($category->id); ?>" data-bs-target="#exampleModalUpdate"><span data-feather="edit" ></span></a>
              <form action="/manajemen/categories/<?php echo e($category->id); ?>" method="post" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button class="badge bg-danger border-0" onclick="return confirm('Yakin hapus?')"><span data-feather="x-circle"></span></button>
              </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center">
      <?php echo e($categories->links()); ?>

  </div>
  </div>

  
  <div class="modal fade" id="exampleModalCreate" tabindex="-1" aria-labelledby="judulModal" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="judulModal">Buat Kategori Baru</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="/manajemen/new_category" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="mb-3">
                  <label for="category_name" class="col-form-label">Nama Kategori</label>
                  <input type="text" class="form-control" id="category_name" name="category_name" value="" required>
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary">Buat Kategori</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  


  <div class="modal fade" id="exampleModalUpdate" tabindex="-1" aria-labelledby="judulModal" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="judulModal">Ubah Kategori</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="/ubahCategories" method="post" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <input type="text" class="form-control" id="id" name="id" value="" hidden>
            <div class="modal-body">
                <div class="mb-3">
                  <label for="category_name2" class="col-form-label">Nama Kategori</label>
                  <input type="text" class="form-control" id="category_name2" name="category_name2" value="" required>
                </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary">Ubah</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-akhir-4.0\resources\views/dashboard/posts/admin.blade.php ENDPATH**/ ?>