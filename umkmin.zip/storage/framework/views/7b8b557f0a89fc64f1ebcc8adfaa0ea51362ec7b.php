<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
     <?php if(auth()->user()->role == 'umkm'): ?>
     <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" aria-current="page" href="/dashboard">
          <span data-feather="home"></span>
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('dashboard/posts*') ? 'active' : ''); ?>" href="/dashboard/posts">
          <span data-feather="file-text"></span>
        Produk Saya
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('dashboard/email') ? 'active' : ''); ?>" href="/dashboard/email">
          <span data-feather="mail"></span>
        Email Masuk
        </a>
      </li>
    </ul>
     <?php else: ?>
     <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('manajemen/categories') ? 'active' : ''); ?>" aria-current="page" href="/manajemen/categories">
          <span data-feather="home"></span>
          Dashboard
        </a>
      </li>
     <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('manajemen/users') ? 'active' : ''); ?>" href="/manajemen/users">
          <span data-feather="file-text"></span>
        Daftar User
        </a>
      </li>
      
    </ul>
     <?php endif; ?>
     
    </div>
  </nav><?php /**PATH C:\django\coba111\resources\views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>