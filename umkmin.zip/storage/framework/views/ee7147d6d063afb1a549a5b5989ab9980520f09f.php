

<?php $__env->startSection('body'); ?>

    <div class="row mt-5 ms-5 me-5">
        <div class="col">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                <a class="nav-link " aria-current="page" href="/company-profile">Gambaran</a>
                </li>
                <li class="nav-item">
                <a class="nav-link active" href="/company-catalogs">Katalog Produk</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/company-appointment">Buat Janji</a>
                </li>
            </ul>
        </div>
    </div>

    <hr class="ms-5 me-5 mt-5">

    <div class="row ms-5 mt-5 me-5">
        <div class="col">
            <h4>Katalog Produk</h4>
            <div class="row my-3 fs-5 ">
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="/company-catalog-1" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 20</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="/company-catalog-1" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 04</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="/company-catalog-1" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 11</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="/company-catalog-1" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 16</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="/company-catalog-1" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 20</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="/company-catalog-1" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 04</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="/company-catalog-1" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 11</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 mb-3">
                    <div class="card">
                        <img src="http://source.unsplash.com/300x200?doors" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="/company-catalog-1" class="text-black" style="text-decoration: none;" ><h5 class="card-title fw-bold hurufbesar">Pintu</h5></a>
                            <p class="card-text fw-light hurufkecil">Pintu Ukiran - Model 16</p>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\coba-akhir-2.0\resources\views/layouts/company/catalogs.blade.php ENDPATH**/ ?>